<?php
$server="localhost";
$user="root";
$pass="";
$dbname="expert";
$conn=mysqli_connect($server,$user,$pass,$dbname);
if($conn)
	echo "k";
else
	echo "N";
?>

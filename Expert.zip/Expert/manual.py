from pyModbusTCP.client import ModbusClient

# init modbus client
c = ModbusClient(host="192.168.2.1", debug=False, auto_open=True)

coils_l = c.write_single_coil(8, 0)
print(coils_l)
<!DOCTYPE html>
<html>
<head>
        <title>Test</title>
</head>
<body>
        <form action="" method="post">
                <button type="submit" name="sub" value="call">test01</button>
        </form>
</body>
</html>

<?php
if(isset($_POST['sub']))
{
        exec('stop.py');
        echo "Picture captured";
}
?>
from pyModbusTCP.client import ModbusClient

# init modbus client
c = ModbusClient(host="192.168.2.1", debug=False, auto_open=True)

FLOW = c.read_holding_registers(2, 1)
print(FLOW)
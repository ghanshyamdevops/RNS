<!DOCTYPE html>
<html lang="en">

<head>

	<title>Expert Engineers.</title>
			
  
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
	
  <!-- Favicons
  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">-->
 	
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Main styles -->
  <link href="css/style.css" rel="stylesheet">
  <!-- Icon fonts-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
   
   <!-- Your custom styles -->
  <link href="css/custom.css" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  
  <link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="js/bootstrap.min.js"></script>
  <script src="jquery/jquery.min.js"></script>
  

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  
  </head>

  <body class="fixed-nav sticky-footer" id="page-top">

    
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-default fixed-top" id="mainNav">
    <a class="navbar-brand" href=""><img src="img/logo2.png" data-retina="true" alt="" width="155" height="36"></a>
	<div class="UppaeMenu">
		<ul class="navbar-nav ml-auto">
			<li class="nav-item">
				<a href="" class="nav-link menu">
				<i class="fa fa-home"></i><b> Home </b></a>
			</li>
			<li class="nav-item">
				<a href="" class="nav-link menu">
				<i class="fa fa-history"></i><b> History </b></a>
			</li>
			<li class="nav-item">
				<a class="nav-link menu" data-toggle="modal" data-target="#alarm">
				<i class="fa fa-clock-o"></i><b> Alarm </b></a>
			</li>
			<li class="nav-item">
				<a class="nav-link menu" data-toggle="modal" data-target="#timer">
				<i class="fa fa-clock-o"></i><b> Timer </b></a>
			</li>
			<li class="nav-item">
				<a class="nav-link menu" data-toggle="modal" data-target="#exampleModal">
				<i class="fa fa-power-off"></i><b> Log Out </b></a>
			</li>
			<li class="nav-item">
				<a class="nav-link menuHead"><b>WATER SUPPLY SCHEME <span style="color:#014884;"> NOIDA</span></b></a>
			</li>
		</ul>				
	</div>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
			<li class="nav-item">
				<a class="nav-link menu">
				<i class="fa fa-map-marker"></i> <b>Borewell 1</b></a>
			</li>
      </ul>
    </div>
  </nav>
  
  <div class="content-wrapper">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">My Dashboard</li>
      </ol> 
      <div class="row">
        <div class="col-md-3 col-sm-12 col-12">
          <div id="columnchart_material" style="height: 500px;"></div>            
        </div>
        <div class="col-md-1 col-sm-12 col-12">
          <img src="img/pump.jpg" alt="">
        </div>
        <div class="col-md-8 col-sm-12 col-12">
          <div class="section2">
          
            <div class="switchname">
              Push Button / Switches
            </div>
            <div class="switchname2">
              Indicator
            </div>                        
          </div>
          <div class="switch">
            <div class="auto">
              <div class="arrow">
                <i class="fa fa-arrow-right fa-2x"></i>
              </div>
              <div class="auto1">
			   
        <form action="" method="post">
                <button type="submit" name="AUTO" value="call">AUTO</button>
        </form>
              
			  </div>
              <div class="auto2">
              <form action="" method="post">
                <button type="submit" name="MANUAL" value="call1">MANUAL</button>
              </form>
             
                </div>
            </div>
            <div class="autoindicate">
                <span>AUTO</span>
            </div>
            <div class="indicateshow"></div>
            <div class="autoindicate2">
              <span>MANUAL</span>
            </div>
            <div class="indicateshow2"></div>
          </div>          
          <div class="pushbutton">
            <div class="onoff">
              <div class="arrow">
                <i class="fa fa-arrow-right fa-2x"></i>
              </div> 
              <div class="auto1">
              <form action="" method="post">
                <button type="submit" name="START" value="call2">START</button>
              </form>
              
              
                </div>
              <div class="auto2">
                           
                 <form action="" method="post">
                <button type="submit" name="STOP" value="call3">STOP</button>
              </form>
              
                </div>       
            </div>
            <div class="autoonoff">
                <span>AUTO</span>
            </div>
            <div class="tripindicateshow">

            </div>
            <div class="autoonoff2">
              <span>MANUAL</span>
            </div>
            <div class="tripindicateshow2">

            </div>
            <div class="autoonoff3">
              <span>TRIP</span>
            </div>
            <div class="tripindicateshow3">

            </div>
          </div>
        </div>
      </div>
	   <div class="row">
        <div class="col-md-6 col-sm-12 col-12">
          <!-- Pump Run Hour-->           
          <div class="pumpstatussection"> 
              

            <table id="customers">
            <meta http-equiv="refresh" content="10">
              <tr>
                <th>Time</th>
                <th>Pump Status</th>
                <th>Time</th>
                <th>Pump Status</th>
              </tr>
              <tr>
                <td>10:00 AM</td>
                <td>ON</td>
                <td>11:00 AM</td>
                <td>OFF</td>
              </tr>
              <tr>
                <td>12:00 PM</td>
                <td>ON</td>
                <td>01:00 PM</td>
                <td>OFF</td>
              </tr>
              <tr>
                <td>10:00 AM</td>
                <td>ON</td>
                <td>11:00 AM</td>
                <td>OFF</td>
              </tr>
              <tr>
                <td>11:00 AM</td>
                <td>ON</td>
                <td>12:00 PM</td>
                <td>OFF</td>
              </tr>
              <tr>
                <td>10:00 AM</td>
                <td>ON</td>
                <td>11:00 AM</td>
                <td>OFF</td>
              </tr>
              <tr>
                <td>10:00 AM</td>
                <td>ON</td>
                <td>11:00 AM</td>
                <td>OFF</td>
              </tr>
              <tr>
                <td>10:00 AM</td>
                <td>ON</td>
                <td>11:00 AM</td>
                <td>OFF</td>
              </tr>
              <tr>
                <td>10:00 AM</td>
                <td>ON</td>
                <td>11:00 AM</td>
                <td>OFF</td>
              </tr>
            </table>  
          </div>            
        </div>
        <div class="col-md-6 col-sm-12 col-12">            
          <!-- Meter Reading-->
          <div class="pumpstatussection"> 
          
          <?php  {  $tmp = exec("pressure.py"); echo  $tmp; }  ?>
          <?php  {  $tmp1 = exec("flow.py"); echo  $tmp1; }  ?>

            <span>Meter Reading</span>

            <table id="customers">
              <tr>
                <th>#</th>
                <th>Parameters</th>
                <th>Value</th>
              </tr>
                <tr>
                  <td>1</td>
                  <td>Voltage</td>
                  <td>415 V</td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Flow</td>
                  <td><?php echo $tmp;?> M <sup>2</sup>/Hr</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Pressure</td>
                  <td><?php echo $tmp1;?> Kg CM<sup>2</sup></td>
                </tr>
                <tr>
                  <td>4</td>
                  <td>Ampear</td>
                  <td>0.00 A</td>
                </tr>
                <tr>
                  <td>5</td>
                  <td>Total Flow</td>
                  <td>10g M <sup>2</sup>/Hr</td>
                </tr>
                <tr>
                  <td>6</td>
                  <td>KW/Hr</td>
                  <td>40 Kw/Hr</td>
                </tr>
                <tr>
                  <td>7</td>
                  <td>Total Energy Consume</td>
                  <td>1698 Kw</td>
                </tr>
                <tr>
                  <td>8</td>
                  <td>Power Factor</td>
                  <td>0.99</td>
                </tr>
            </table>  
          </div> 
        </div>
      </div>
    </div>
	   <!-- /.container-wrapper-->
    
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © 2021 Unique Power & Automation Pvt. Ltd.</small>
        </div>
      </div>
    </footer>
<!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	 <!-- Custom scripts for all pages-->
    
	<!-- Custom scripts for this page-->
	<script src="vendor/dropzone.min.js"></script>
	<script src="vendor/bootstrap-datepicker.js"></script>
	<!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>		
  </body>
</html>
	
<?php
if(isset($_POST['AUTO']))
{
  exec('auto.py');
  echo "Picture captured";
}	
?>

<?php
if(isset($_POST['MANUAL']))
{
  exec('manual.py');
  echo "Picture captured";
}	
?>

<?php
if(isset($_POST['START']))
{
  exec('start.py');
  echo "Picture captured";
}	
?>

<?php
if(isset($_POST['STOP']))
{
  exec('stop.py');
  echo "Picture captured";
}	
?>